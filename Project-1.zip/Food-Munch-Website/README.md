# Food-Munch-Website

Developed a responsive website for Food Store where users can see a list of food items, detailed information about a food item, offers

* Designed page using following HTML structure elements like li, header, article, footer elements and different bootstrap components to show different sections in the website and different bootstrap classes for responsiveness through mobile-first approach.

* Implemented product youtube videos by using bootstrap embed and model components

Technologies used: HTML, CSS, Bootstrap
